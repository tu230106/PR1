import java.util.Scanner;

public class StudentMajor {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter two characters: ");

        String s = sc.next();
        char majorChar = s.charAt(0);
        char yearChar = s.charAt(1);

        String major = "";
        if (majorChar == 'M') major = "Mathematics";
        else if (majorChar == 'C') major = "Computer Science";
        else if (majorChar == 'i') major = "Information Technology";
        else {
            System.out.println("Invalid input");
            return;
        }

        String year = "";
        if (yearChar == '1') year = "Freshman";
        else if (yearChar == '2') year = "Sophomore";
        else if (yearChar == '3') year = "Junior";
        else if (yearChar == '4') year = "Senior";
        else {
            System.out.println("Invalid input");
            return;
        }

        System.out.println(major + " " + year);
    }
}
